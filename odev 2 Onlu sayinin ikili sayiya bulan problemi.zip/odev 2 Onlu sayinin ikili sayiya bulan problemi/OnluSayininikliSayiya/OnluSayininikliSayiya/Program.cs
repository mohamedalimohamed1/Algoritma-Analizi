﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Onluk sayı girin: ");
        int onlukSayi = Convert.ToInt32(Console.ReadLine());

        // Iteratif (döngü kullanarak) ikiliye dönüşüm
        string binaryIterative = DecimalToBinaryIterative(onlukSayi);
        Console.WriteLine("Iteratif dönüşüm: {0}", binaryIterative);

        // Özyinelemeli (recursive) ikiliye dönüşüm
        string binaryRecursive = DecimalToBinaryRecursive(onlukSayi);
        Console.WriteLine("Özyinelemeli dönüşüm: {0}", binaryRecursive);
    }

    // Iteratif (döngü kullanarak) ikiliye dönüşüm
    static string DecimalToBinaryIterative(int decimalNumber)
    {
        if (decimalNumber == 0)
            return "0";

        Stack<int> binaryStack = new Stack<int>();

        while (decimalNumber > 0)
        {
            binaryStack.Push(decimalNumber % 2);
            decimalNumber /= 2;
        }

        string binaryString = "";
        while (binaryStack.Count > 0)
        {
            binaryString += binaryStack.Pop();
        }

        return binaryString;
    }

    // Özyinelemeli (recursive) ikiliye dönüşüm
    static string DecimalToBinaryRecursive(int decimalNumber)
    {
        if (decimalNumber == 0)
            return "";

        int remainder = decimalNumber % 2;
        return DecimalToBinaryRecursive(decimalNumber / 2) + remainder;
    }
}
