﻿using System;

class TSP
{
    static int[,] distances; // Şehirler arasındaki mesafe matrisi
    static int numCities; // Şehir sayısı
    static bool[] visited; // Ziyaret edilip edilmediğini takip etmek için

    // Gezgin satıcı problemi için recursive yöntem
    static int TSPRecursive(int currentCity, int visitedCities)
    {
        if (visitedCities == (1 << numCities) - 1)
            return distances[currentCity, 0]; // Başlangıç noktasına dön

        int minDistance = int.MaxValue;

        for (int nextCity = 0; nextCity < numCities; nextCity++)
        {
            if ((visitedCities & (1 << nextCity)) == 0)
            {
                visited[nextCity] = true;
                int distance = distances[currentCity, nextCity] + TSPRecursive(nextCity, visitedCities | (1 << nextCity));
                minDistance = Math.Min(minDistance, distance);
                visited[nextCity] = false;
            }
        }

        return minDistance;
    }

    static void Main(string[] args)
    {
        Console.Write("Kaç şehir var?: ");
        numCities = Convert.ToInt32(Console.ReadLine());

        distances = new int[numCities, numCities];
        visited = new bool[numCities];

        // Şehirler arasındaki mesafeleri kullanıcıdan al
        for (int i = 0; i < numCities; i++)
        {
            for (int j = 0; j < numCities; j++)
            {
                if (i != j)
                {
                    Console.Write("Şehir {0} ile {1} arasındaki mesafe: ", i + 1, j + 1);
                    distances[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }
        }

        visited[0] = true; // Başlangıç noktası ziyaret edildi kabul edilir
        int shortestDistance = TSPRecursive(0, 1 << 0); // 0. şehirden başlanır
        Console.WriteLine("En kısa yolun uzunluğu: " + shortestDistance);
    }
}
