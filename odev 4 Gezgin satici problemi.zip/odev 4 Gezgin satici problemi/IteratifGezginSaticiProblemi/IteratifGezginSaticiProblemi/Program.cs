﻿using System;

class TSP
{
    static int[,] distances; // Şehirler arasındaki mesafe matrisi
    static int numCities; // Şehir sayısı

    // Gezgin satıcı problemi için iteratif yöntem
    static int TSPIterative()
    {
        // Tüm şehirlerin permütasyonlarını oluşturma
        int[] path = new int[numCities];
        for (int i = 0; i < numCities; i++)
            path[i] = i;

        int shortestDistance = int.MaxValue;

        do
        {
            int distance = 0;
            for (int i = 0; i < numCities - 1; i++)
                distance += distances[path[i], path[i + 1]];
            distance += distances[path[numCities - 1], path[0]]; // Başlangıç noktasına dön

            shortestDistance = Math.Min(shortestDistance, distance);
        } while (NextPermutation(path));

        return shortestDistance;
    }

    // Bir sonraki permütasyonu bulma
    static bool NextPermutation(int[] path)
    {
        int i = path.Length - 1;
        while (i > 0 && path[i - 1] >= path[i])
            i--;
        if (i <= 0)
            return false;

        int j = path.Length - 1;
        while (path[j] <= path[i - 1])
            j--;

        // Swap
        int temp = path[i - 1];
        path[i - 1] = path[j];
        path[j] = temp;

        // Reverse
        j = path.Length - 1;
        while (i < j)
        {
            temp = path[i];
            path[i] = path[j];
            path[j] = temp;
            i++;
            j--;
        }

        return true;
    }

    static void Main(string[] args)
    {
        Console.Write("Kaç şehir var?: ");
        numCities = Convert.ToInt32(Console.ReadLine());

        distances = new int[numCities, numCities];

        // Şehirler arasındaki mesafeleri kullanıcıdan al
        for (int i = 0; i < numCities; i++)
        {
            for (int j = 0; j < numCities; j++)
            {
                if (i != j)
                {
                    Console.Write("Şehir {0} ile {1} arasındaki mesafe: ", i + 1, j + 1);
                    distances[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }
        }

        // En kısa yolun uzunluğunu hesapla ve yazdır
        int shortestDistance = TSPIterative();
        Console.WriteLine("En kısa yolun uzunluğu: " + shortestDistance);
    }
}
