﻿using System;

class Program
{
    static long FactorialIterative(int n)
    {
        long result = 1;
        for (int i = 2; i <= n; i++)
        {
            result *= i;
        }
        return result;
    }

    static void Main(string[] args)
    {
        int number = 5; // Faktöriyeli alınacak sayı
        long factorial = FactorialIterative(number);
        Console.WriteLine("Iteratif Faktöriyel: " + factorial);
    }
}
