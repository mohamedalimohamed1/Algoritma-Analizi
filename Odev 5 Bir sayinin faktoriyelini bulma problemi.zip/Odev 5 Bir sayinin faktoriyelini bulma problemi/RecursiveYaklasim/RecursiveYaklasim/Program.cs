﻿using System;

class Program
{
    static long FactorialRecursive(int n)
    {
        if (n == 0 || n == 1)
        {
            return 1;
        }
        else
        {
            return n * FactorialRecursive(n - 1);
        }
    }

    static void Main(string[] args)
    {
        int number = 5; // Faktöriyeli alınacak sayı
        long factorial = FactorialRecursive(number);
        Console.WriteLine("Recursive Faktöriyel: " + factorial);
    }
}

