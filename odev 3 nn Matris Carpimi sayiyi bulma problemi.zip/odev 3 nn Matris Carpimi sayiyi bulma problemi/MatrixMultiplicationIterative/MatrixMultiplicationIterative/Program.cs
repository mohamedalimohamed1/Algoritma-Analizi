﻿using System;

class Program
{
    static int[,] MatrixMultiplicationIterative(int[,] matrix1, int[,] matrix2, int n)
    {
        int[,] result = new int[n, n];

        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                result[i, j] = 0;
                for (int k = 0; k < n; k++)
                {
                    result[i, j] += matrix1[i, k] * matrix2[k, j];
                }
            }
        }

        return result;
    }

    static void Main(string[] args)
    {
        Console.Write("Matris boyutunu girin (n x n): ");
        int n = Convert.ToInt32(Console.ReadLine());

        int[,] matrix1 = new int[n, n];
        int[,] matrix2 = new int[n, n];

        Console.WriteLine("Matris 1'in elemanlarını girin:");
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                Console.Write("Eleman [{0},{1}]: ", i, j);
                matrix1[i, j] = Convert.ToInt32(Console.ReadLine());
            }
        }

        Console.WriteLine("Matris 2'nin elemanlarını girin:");
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                Console.Write("Eleman [{0},{1}]: ", i, j);
                matrix2[i, j] = Convert.ToInt32(Console.ReadLine());
            }
        }

        int[,] result = MatrixMultiplicationIterative(matrix1, matrix2, n);
        Console.WriteLine("\nIteratif Matris Çarpımı Sonucu:");
        PrintMatrix(result, n);
    }

    static void PrintMatrix(int[,] matrix, int n)
    {
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                Console.Write(matrix[i, j] + " ");
            }
            Console.WriteLine();
        }
    }
}
