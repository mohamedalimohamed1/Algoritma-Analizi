﻿using System;

class TSP
{
    static int[,] distances; // Şehirler arasındaki mesafe matrisi
    static int numCities; // Şehir sayısı

    // Gezgin satıcı problemi için Brute Force yöntemi
    static int TSPBruteForce(int[] path, bool[] visited, int current, int length)
    {
        // Tüm şehirler ziyaret edildiyse başlangıç şehrine geri dön
        if (length == numCities)
            return distances[current, 0];

        int minDistance = int.MaxValue;

        // Tüm şehirler için en kısa yolu bul
        for (int i = 0; i < numCities; i++)
        {
            if (!visited[i])
            {
                visited[i] = true;
                path[length] = i;
                int distance = distances[current, i] + TSPBruteForce(path, visited, i, length + 1);
                minDistance = Math.Min(minDistance, distance);
                visited[i] = false;
            }
        }

        return minDistance;
    }

    static void Main(string[] args)
    {
        Console.Write("Kaç şehir var?: ");
        numCities = Convert.ToInt32(Console.ReadLine());

        distances = new int[numCities, numCities];

        // Şehirler arasındaki mesafeleri kullanıcıdan al
        for (int i = 0; i < numCities; i++)
        {
            for (int j = 0; j < numCities; j++)
            {
                if (i != j)
                {
                    Console.Write("Şehir {0} ile {1} arasındaki mesafe: ", i + 1, j + 1);
                    distances[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }
        }

        // Başlangıç şehri olarak 0 kabul edilir
        int[] path = new int[numCities];
        bool[] visited = new bool[numCities];
        visited[0] = true;

        // En kısa yolun uzunluğunu hesapla
        int shortestDistance = TSPBruteForce(path, visited, 0, 1);

        Console.WriteLine("En kısa yolun uzunluğu: " + shortestDistance);
    }
}

