﻿//Prim Algoritması Çalışma Mantığı
//Prim algoritması, minimum kapsama ağacı (Minimum Spanning Tree - MST) problemini çözmek için kullanılan bir açgözlü algoritmadır. Bu algoritma, başlangıçta bir düğümü seçer ve bu düğümden başlayarak, her adımda en düşük ağırlıklı kenarı seçerek ağacı genişletir.

//Çalışma Adımları:
//Rastgele bir başlangıç düğümü seç.
//Bu düğümden çıkabilen en düşük ağırlıklı kenarı seç ve bu kenar ile diğer düğümü ağaca ekle.
//Ağaca yeni eklenen düğümden çıkabilen en düşük ağırlıklı kenarı seç ve çevrim oluşturmadan ağaca ekle.
//Bu işlemi tüm düğümler ağaca eklenene kadar tekrarla.
//Karmaşıklık
//Zaman Karmaşıklığı: O(V ^ 2), burada V düğüm sayısıdır. Öncelik kuyruğu kullanılarak O(E log V) seviyesine indirilebilir.
//Uzay Karmaşıklığı: O(V), çünkü her düğüm için bir maliyet ve bir önceki düğüm saklanır.

using System;

class Graph
{
    private int Vertices; // Düğüm sayısı
    private int[,] graph; // Grafın bitişiklik matrisi

    public Graph(int vertices)
    {
        Vertices = vertices; // Düğüm sayısını ata
        graph = new int[vertices, vertices]; // Matris başlat
    }

    // Graf kenar ağırlıklarını ekleme
    public void AddEdge(int u, int v, int weight)
    {
        graph[u, v] = weight; // Kenar ağırlığını ekle
        graph[v, u] = weight; // Yönsüz graf için ters kenarı da ekle
    }

    // Minimum maliyetli düğümü bulma metodu
    private int MinKey(int[] key, bool[] mstSet)
    {
        int min = int.MaxValue, minIndex = -1;

        for (int v = 0; v < Vertices; v++)
        {
            if (mstSet[v] == false && key[v] < min)
            {
                min = key[v]; // Minimum değeri güncelle
                minIndex = v; // Minimum indeksini güncelle
            }
        }

        return minIndex; // En düşük maliyetli düğümü döndür
    }

    // Prim Algoritması
    public void PrimMST()
    {
        int[] parent = new int[Vertices]; // MST'nin oluşturulması için dizi
        int[] key = new int[Vertices]; // Düğüm maliyetlerini saklamak için dizi
        bool[] mstSet = new bool[Vertices]; // Ziyaret edilen düğümleri izlemek için dizi

        for (int i = 0; i < Vertices; i++)
        {
            key[i] = int.MaxValue; // Tüm maliyetleri sonsuz olarak başlat
            mstSet[i] = false; // Tüm düğümleri ziyaret edilmemiş olarak başlat
        }

        key[0] = 0; // Başlangıç düğüm maliyetini 0 yap
        parent[0] = -1; // İlk düğümün parent'i yok

        for (int count = 0; count < Vertices - 1; count++)
        {
            int u = MinKey(key, mstSet); // En düşük maliyetli düğümü seç
            mstSet[u] = true; // Bu düğümü ziyaret edilmiş olarak işaretle

            for (int v = 0; v < Vertices; v++)
            {
                if (graph[u, v] != 0 && mstSet[v] == false && graph[u, v] < key[v])
                {
                    parent[v] = u; // Parent'i güncelle
                    key[v] = graph[u, v]; // Anahtar değeri güncelle
                }
            }
        }

        PrintMST(parent); // Sonuçları yazdır
    }

    // MST'yi yazdırma metodu
    private void PrintMST(int[] parent)
    {
        Console.WriteLine("Kenar \tAğırlık");
        for (int i = 1; i < Vertices; i++)
            Console.WriteLine(parent[i] + " - " + i + "\t" + graph[i, parent[i]]);
    }
}

// Ana program
class Program
{
    static void Main(string[] args)
    {
        Graph g = new Graph(5); // 5 düğümlü graf oluştur

        // Kenar eklemeleri
        g.AddEdge(0, 1, 2);
        g.AddEdge(0, 3, 6);
        g.AddEdge(1, 2, 3);
        g.AddEdge(1, 3, 8);
        g.AddEdge(1, 4, 5);
        g.AddEdge(2, 4, 7);
        g.AddEdge(3, 4, 9);

        g.PrimMST(); // Prim algoritmasını başlat
    }
}
