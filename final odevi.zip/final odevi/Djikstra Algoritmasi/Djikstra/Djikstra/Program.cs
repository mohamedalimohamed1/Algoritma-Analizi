﻿//Dijkstra Algoritması Çalışma Mantığı
//Dijkstra algoritması, bir grafın belirli bir başlangıç düğümünden diğer tüm düğümlere olan en kısa yolları bulmak için kullanılan bir algoritmadır. Algoritma, ağırlıklı bir grafın her bir düğümüne olan en kısa yolu adım adım belirler ve bu süreçte her adımda en düşük maliyetli düğümü seçer.

//Çalışma Adımları:
//Başlangıç düğümünden başla ve bu düğümün maliyetini 0 olarak ayarla. Diğer tüm düğümlerin maliyetini sonsuz olarak başlat.
//Henüz ziyaret edilmemiş düğümler arasından maliyeti en düşük olan düğümü seç.
//Seçilen düğümün komşu düğümleri için:
//Eğer bu komşu düğüme olan mevcut maliyet, seçilen düğüm üzerinden geçiş yaparak daha düşük bir maliyete indirilebiliyorsa, maliyeti güncelle.
//Tüm düğümler ziyaret edilene kadar veya hedef düğüme ulaşılana kadar adım 2 ve 3'ü tekrarla.
//Karmaşıklık
//Zaman Karmaşıklığı: O(V ^ 2), burada V düğüm sayısıdır. Daha etkin veri yapıları (örneğin, öncelik kuyruğu kullanarak) kullanılarak O((V + E) log V) karmaşıklığına indirilebilir.
//Uzay Karmaşıklığı: O(V), çünkü her düğüm için bir maliyet ve bir önceki düğüm saklanır.

using System;
using System.Collections.Generic;

class Graph
{
    private int Vertices; // Grafın düğüm sayısı
    private List<Tuple<int, int>>[] adjacencyList; // Komşuluk listesi gösterimi

    // Graf oluşturucu
    public Graph(int vertices)
    {
        Vertices = vertices; // Düğüm sayısını ata
        adjacencyList = new List<Tuple<int, int>>[vertices]; // Komşuluk listesi dizisi oluştur
        for (int i = 0; i < vertices; i++)
            adjacencyList[i] = new List<Tuple<int, int>>(); // Her düğüm için yeni bir liste başlat
    }

    // Kenar ekleme metodu
    public void AddEdge(int u, int v, int weight)
    {
        adjacencyList[u].Add(new Tuple<int, int>(v, weight)); // Düğüme kenar ve ağırlık ekle
        adjacencyList[v].Add(new Tuple<int, int>(u, weight)); // Yönsüz graf için ters kenar ekle
    }

    // Dijkstra algoritması
    public void Dijkstra(int start)
    {
        int[] distances = new int[Vertices]; // Düğüm maliyetlerini saklamak için dizi
        bool[] shortestPathTreeSet = new bool[Vertices]; // Ziyaret edilen düğümleri izlemek için dizi

        for (int i = 0; i < Vertices; i++)
        {
            distances[i] = int.MaxValue; // Tüm maliyetleri sonsuz olarak başlat
            shortestPathTreeSet[i] = false; // Tüm düğümleri ziyaret edilmemiş olarak başlat
        }

        distances[start] = 0; // Başlangıç düğüm maliyetini 0 yap

        for (int count = 0; count < Vertices - 1; count++)
        {
            int u = MinimumDistance(distances, shortestPathTreeSet); // En düşük maliyetli düğümü seç
            shortestPathTreeSet[u] = true; // Bu düğümü ziyaret edilmiş olarak işaretle

            foreach (var neighbor in adjacencyList[u])
            {
                int v = neighbor.Item1; // Komşu düğüm
                int weight = neighbor.Item2; // Kenar ağırlığı

                if (!shortestPathTreeSet[v] && distances[u] != int.MaxValue && distances[u] + weight < distances[v])
                {
                    distances[v] = distances[u] + weight; // Daha düşük maliyet bulunursa güncelle
                }
            }
        }

        Print(distances); // Sonuçları yazdır
    }

    // En düşük maliyetli düğümü bulma metodu
    private int MinimumDistance(int[] distances, bool[] shortestPathTreeSet)
    {
        int min = int.MaxValue;
        int minIndex = -1;

        for (int v = 0; v < Vertices; v++)
        {
            if (shortestPathTreeSet[v] == false && distances[v] <= min)
            {
                min = distances[v]; // Minimum maliyeti güncelle
                minIndex = v; // Minimum maliyetli düğümün indeksini güncelle
            }
        }

        return minIndex; // En düşük maliyetli düğümü döndür
    }

    // Sonuçları yazdırma metodu
    private void Print(int[] distances)
    {
        Console.WriteLine("Düğüm Mesafeleri:");
        for (int i = 0; i < Vertices; i++)
            Console.WriteLine(i + " \t\t " + distances[i]); // Düğüm ve maliyeti yazdır
    }
}

// Ana program
class Program
{
    static void Main(string[] args)
    {
        Graph g = new Graph(9); // 9 düğümlü graf oluştur

        // Kenar eklemeleri
        g.AddEdge(0, 1, 4);
        g.AddEdge(0, 7, 8);
        g.AddEdge(1, 2, 8);
        g.AddEdge(1, 7, 11);
        g.AddEdge(2, 3, 7);
        g.AddEdge(2, 8, 2);
        g.AddEdge(2, 5, 4);
        g.AddEdge(3, 4, 9);
        g.AddEdge(3, 5, 14);
        g.AddEdge(4, 5, 10);
        g.AddEdge(5, 6, 2);
        g.AddEdge(6, 7, 1);
        g.AddEdge(6, 8, 6);
        g.AddEdge(7, 8, 7);

        g.Dijkstra(0); // Dijkstra algoritmasını başlat
    }
}
