﻿//Kruskal Algoritması Çalışma Mantığı
//Kruskal algoritması, minimum kapsama ağacı (Minimum Spanning Tree - MST) problemini çözmek için kullanılan bir açgözlü algoritmadır. Amaç, bir grafın tüm düğümlerini kapsayan, ağırlıkları toplamı en küçük olan çevrimsiz bir alt graf oluşturmaktır.

//Çalışma Adımları:
//Tüm kenarları ağırlıklarına göre artan şekilde sırala.
//En küçük ağırlıklı kenardan başlayarak, çevrim oluşturmayacak şekilde kenarları seç ve MST'ye ekle.
//Bu işlemi, tüm düğümler MST'de yer alana kadar veya n-1 kenar eklenene kadar tekrarla (n, düğüm sayısıdır).
//Karmaşıklık
//Zaman Karmaşıklığı: O(E log E), burada E kenar sayısıdır. Çünkü kenarları sıralama işlemi en baskın adımdır.
//Uzay Karmaşıklığı: O(V + E), çünkü kenarlar ve düğümler için ayrı ayrı bellek gereksinimi vardır.

using System;
using System.Collections.Generic;

class Edge : IComparable<Edge>
{
    public int Source, Destination, Weight; // Kenar özellikleri

    public int CompareTo(Edge compareEdge)
    {
        return this.Weight - compareEdge.Weight; // Kenar ağırlıklarına göre karşılaştırma
    }
}

class Graph
{
    private int Vertices, Edges; // Düğüm ve kenar sayıları
    public Edge[] edge; // Kenar dizisini public yaptık

    public Graph(int vertices, int edges)
    {
        Vertices = vertices; // Düğüm sayısını ata
        Edges = edges; // Kenar sayısını ata
        edge = new Edge[edges]; // Kenar dizisini başlat
        for (int i = 0; i < edges; i++)
            edge[i] = new Edge(); // Her bir kenar için yeni nesne oluştur
    }

    private int Find(int[] parent, int i)
    {
        if (parent[i] == i) // Eğer düğüm kendi parent'i ise döndür
            return i;
        return Find(parent, parent[i]); // Değilse, parent'ini bulmak için rekürsif çağrı yap
    }

    private void Union(int[] parent, int[] rank, int x, int y)
    {
        int rootX = Find(parent, x);
        int rootY = Find(parent, y);

        if (rank[rootX] < rank[rootY])
            parent[rootX] = rootY; // Kökü daha düşük rütbeye sahip olanı diğerine bağla
        else if (rank[rootX] > rank[rootY])
            parent[rootY] = rootX; // Kökü daha yüksek rütbeye sahip olanı diğerine bağla
        else
        {
            parent[rootY] = rootX; // Eşit rütbelerdeyse birini diğerine bağla
            rank[rootX]++; // Bağlanan kökün rütbesini artır
        }
    }

    public void KruskalMST()
    {
        Edge[] result = new Edge[Vertices]; // Sonuç dizisi
        int e = 0; // Sonuç dizisi için sayaç
        int i = 0; // Sıralı kenarları takip etmek için sayaç

        Array.Sort(edge); // Kenarları ağırlıklarına göre sırala

        int[] parent = new int[Vertices]; // Parent dizisi
        int[] rank = new int[Vertices]; // Rütbe dizisi

        for (int v = 0; v < Vertices; ++v)
        {
            parent[v] = v; // Her düğümün parent'ini kendisi olarak başlat
            rank[v] = 0; // Tüm rütbeleri 0 olarak başlat
        }

        while (e < Vertices - 1)
        {
            Edge nextEdge = edge[i++]; // Sıradaki kenarı al

            int x = Find(parent, nextEdge.Source); // Kaynak düğümün kökünü bul
            int y = Find(parent, nextEdge.Destination); // Hedef düğümün kökünü bul

            if (x != y)
            {
                result[e++] = nextEdge; // Sonuç dizisine ekle ve sayacı artır
                Union(parent, rank, x, y); // Kökleri birleştir
            }
        }

        Console.WriteLine("Minimum Spanning Tree oluşturulmuş kenarlar:");
        for (i = 0; i < e; ++i)
            Console.WriteLine(result[i].Source + " -- " + result[i].Destination + " == " + result[i].Weight);
    }
}

// Ana program
class Program
{
    static void Main(string[] args)
    {
        int vertices = 4; // Düğüm sayısı
        int edges = 5; // Kenar sayısı
        Graph graph = new Graph(vertices, edges); // Graf oluştur

        // Kenar eklemeleri
        graph.edge[0].Source = 0;
        graph.edge[0].Destination = 1;
        graph.edge[0].Weight = 10;

        graph.edge[1].Source = 0;
        graph.edge[1].Destination = 2;
        graph.edge[1].Weight = 6;

        graph.edge[2].Source = 0;
        graph.edge[2].Destination = 3;
        graph.edge[2].Weight = 5;

        graph.edge[3].Source = 1;
        graph.edge[3].Destination = 3;
        graph.edge[3].Weight = 15;

        graph.edge[4].Source = 2;
        graph.edge[4].Destination = 3;
        graph.edge[4].Weight = 4;

        graph.KruskalMST(); // Kruskal algoritmasını başlat
    }
}

