﻿using System;

class Program
{
    static void Main(string[] args)
    {
        int[] numbers = { 12, 45, 78, 23, 56, 89, 34, 67 };

        // Iteratif (döngü kullanarak) en büyük sayıyı bulma
        int maxIterative = FindMaxIterative(numbers);
        Console.WriteLine("Iteratif olarak en büyük sayı: " + maxIterative);

        // Özyinelemeli (recursive) en büyük sayıyı bulma
        int maxRecursive = FindMaxRecursive(numbers, 0, numbers.Length - 1);
        Console.WriteLine("Özyinelemeli olarak en büyük sayı: " + maxRecursive);
    }

    // Iteratif (döngü kullanarak) en büyük sayıyı bulma
    static int FindMaxIterative(int[] arr)
    {
        if (arr.Length == 0)
            throw new InvalidOperationException("Dizi boş.");

        int max = arr[0];
        for (int i = 1; i < arr.Length; i++)
        {
            if (arr[i] > max)
                max = arr[i];
        }
        return max;
    }

    // Özyinelemeli (recursive) en büyük sayıyı bulma
    static int FindMaxRecursive(int[] arr, int start, int end)
    {
        if (start == end)
            return arr[start];

        int middle = (start + end) / 2;
        int maxLeft = FindMaxRecursive(arr, start, middle);
        int maxRight = FindMaxRecursive(arr, middle + 1, end);

        return Math.Max(maxLeft, maxRight);
    }
}
